#import pipeline
import pipeline
import transformers
import torch

model_id = "meta-llama/Meta-Llama-3-8B"

pipeline = transformers.pipeline('Hey how are you doing today')
